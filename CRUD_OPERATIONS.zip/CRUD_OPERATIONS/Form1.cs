﻿using System;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;

namespace CRUD_OPERATIONS
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        SqlConnection conn = new SqlConnection("Data Source=DESKTOP-2L4EST4\\SQLEXPRESS;Initial Catalog=Student_info;Integrated Security=True");
        public int studentID;

        private void Form1_Load(object sender, EventArgs e)
        {
            GetStudentsRecord();
        }

        private void GetStudentsRecord()
        {
            
            SqlCommand cmd = new SqlCommand("select * from StudentInfo", conn);

            DataTable dt = new DataTable();

            conn.Open();

            SqlDataReader sdr = cmd.ExecuteReader();
            dt.Load(sdr);

            conn.Close();

            dataGridView1.DataSource = dt;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(IsValid())
            {
                SqlCommand cmd = new SqlCommand("insert into StudentInfo values (@name, @roll, @semester, @depertment, @cgpa)", conn);
                cmd.CommandType = CommandType.Text;

                cmd.Parameters.AddWithValue("@name", textBox1.Text);
                cmd.Parameters.AddWithValue("@roll", textBox2.Text);
                cmd.Parameters.AddWithValue("@semester", textBox3.Text);
                cmd.Parameters.AddWithValue("@depertment", textBox4.Text);
                cmd.Parameters.AddWithValue("@cgpa", textBox5.Text);

                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();

                MessageBox.Show("New student is successfully inserted in the database", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                GetStudentsRecord();

                resetForm();
            }
        }

        private bool IsValid()
        {
            if(textBox1.Text == string.Empty)
            {
                MessageBox.Show("Student name is required", "Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            resetForm();
        }

        private void resetForm()
        {
            studentID = 0;
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();

            textBox1.Focus();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            studentID = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value);
            textBox1.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            textBox2.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
            textBox3.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
            textBox4.Text = dataGridView1.SelectedRows[0].Cells[4].Value.ToString();
            textBox5.Text = dataGridView1.SelectedRows[0].Cells[5].Value.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (studentID > 0)
            {
                SqlCommand cmd = new SqlCommand("update StudentInfo set name = @name, roll = @roll, semester = @semester, depertment = @depertment, cgpa = @cgpa where studentID = @studentID", conn);
                cmd.CommandType = CommandType.Text;

                cmd.Parameters.AddWithValue("@name", textBox1.Text);
                cmd.Parameters.AddWithValue("@roll", textBox2.Text);
                cmd.Parameters.AddWithValue("@semester", textBox3.Text);
                cmd.Parameters.AddWithValue("@depertment", textBox4.Text);
                cmd.Parameters.AddWithValue("@cgpa", textBox5.Text);
                cmd.Parameters.AddWithValue("@studentID", this.studentID);

                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();

                MessageBox.Show("Student info updated successfully", "Updated!", MessageBoxButtons.OK, MessageBoxIcon.Information);

                GetStudentsRecord();

                resetForm();
            }
            else
            {
                MessageBox.Show("Please select a student first.", "Select?", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (studentID > 0)
            {

                SqlCommand cmd = new SqlCommand("delete from StudentInfo where studentID = @studentID", conn);
                cmd.CommandType = CommandType.Text;

                cmd.Parameters.AddWithValue("@studentID", this.studentID);

                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();

                MessageBox.Show("Student is deletd from the database.", "Deleted!", MessageBoxButtons.OK, MessageBoxIcon.Information);

                GetStudentsRecord();

                resetForm();

                
            }
            else
                MessageBox.Show("Please select a student first.", "Select?", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
}
